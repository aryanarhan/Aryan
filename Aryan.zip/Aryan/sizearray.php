<?php
$size=array("Big","Small","Medium","Large");
echo count($size);
?>