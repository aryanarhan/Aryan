<?php
$season=array("Summer","Winter","Rainy");
for($i=0;$i<2;$i++)
{
    echo "Seasons are:$season[0],$season[1],$season[2]<br>";
}
?>