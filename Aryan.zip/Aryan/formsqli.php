<?php
$con=mysqli_connect($host="localhost",$user="root",$password="")or die(mysqli_error($con));
echo "Connected Succesfully<br>";
// $sql=mysqli_query($con,"create database meesho")or die(mysqli_error($con));
echo "Database Created Succesfully<br>";
$sel=mysqli_select_db($con,"amazon")or die(mysqli_error($con));
echo "Database Selected Succesfully<br>";
// $tab=mysqli_query($con,"create table name2(id int,name varchar(30),address varchar(50),phone int)")or die(mysqli_error($con));
// echo "table created";
if(isset($_POST['sub']))
{
$id=$_POST=['a'];
$name=$_POST['b'];
$address=$_POST['c'];
$phone=$_POST['d'];
$ins=mysqli_query($con,"insert into user2(id,name,address,phone) values($id,'$name','$address',$phone)")or die(mysqli_error($con));
echo "Data Inserted Succesfully ";
}
if(isset($_POST['delete']))
{
    $id=$_POST=['a'];
$deleted=mysqli_query($con,"delete from user where id=$id")or die(mysqli_error($con));
echo "Deleted";
}
?>
<form method="post">
    Enter id<br><input type="number" name="a"><br>
    Enter name<br><input type="text" name="b"><br>
    Enter address<br><input type="text" name="c"><br>
    Enter phone no<br><input type="text" name="d"><br>
    <input type="submit" name="sub" value="insert"><input type="submit" name="delete" value="delete"></div>