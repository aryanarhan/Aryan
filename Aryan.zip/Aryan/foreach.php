<?php
$size=array("Big","Medium","Large");
foreach($size as $s)
{
    echo "Size is:$s<br>";
}
?><br>
<?php
$size=array("Big","Medium","Large");
echo count($size);
?><br><br>
<?php
$fighter=array("Khabib","Islam","Magomad","Jon Jones","Khamzat");
$tobesearch=4;
for($i=0;$i<=$tobesearch;$i++)
{
    echo "$fighter[$i]<br>";
}
?>