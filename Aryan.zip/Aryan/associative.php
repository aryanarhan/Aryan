<?php
$salary=array("Aryan"=>"50000000","Vimal"=>"4000000","Ratan"=>"5500000");
foreach($salary as $k=>$v){
    echo "Key:".$k."Value".$v."<br>";
}
?><br>
<?php
$salary["Sonoo"]="550000";
$salary["Vimal"]="50000";
$salary["Ratan"]="45000";
echo "Sonoo salary".$salary["Sonoo"]."<br>";
echo "Vimal salary".$salary["Vimal"]."<br>";
echo "Ratan salary".$salary["Ratan"]."<br>";
?>