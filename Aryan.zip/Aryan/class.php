<?php
class MyClass
{
    
}
$obj=new MyClass;
var_dump($obj);
?><br><br>
<?php
class MyClasses
{
    
}
$object=new MyClasses;
var_dump($object);
?>