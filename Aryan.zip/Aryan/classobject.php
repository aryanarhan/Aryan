<?php
class demo
{
    private $a="Hello HIIT Ambala";
    public function display()
    {
        echo $this->a;
    }
}
$obj=new demo();
$obj->display();
?>