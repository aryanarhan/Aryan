<?php
$season=array("Autumn","Winter","Summer","Rainy");
echo "Seasons are:$season[0],$season[1],$season[2],$season[3]";
?><br>
<?php
$season[0]="Summer";
$season[1]="Winter";
$season[2]="Autumn";
$season[3]="Rainy";
echo "Seasons are:$season[0],$season[1],$season[2],$season[3]";
?>