<?php
$season=array("Summer","Winter","Autumn","Rainy");
$tobesearch=3;
for($i=0;$i<=$tobesearch;$i++){
    echo "$season[$i]<br>";
}
?>