<?php
session_start();
?>
<html>
    <body>
        <?php
            $_SESSION["User"]="Sachin";
            echo "Session Information are set Succesfully<br>";
        ?>
        <a href="array.php">Array PHP</a><br>
        <a href="foreach.php">Foreach PHP</a><br>
        <a href="session.php">Session PHP</a><br>
        <a href="classobject.php">Class and Object</a><br>
        <a href="sizearray.php">Size Array</a>
    </body>
</html>