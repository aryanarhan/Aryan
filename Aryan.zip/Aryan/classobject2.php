<?php
class demo
{
    private $a="Islam Mackachaev";
    public function display()
    {
        echo $this->a;
    }
}
$obj=new demo();
$obj->display();
var_dump($obj);
?>