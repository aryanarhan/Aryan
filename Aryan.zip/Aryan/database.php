<?php 
$con=mysqli_connect($host="localhost",$user="root",$password="")or die(mysqli_error($con));
echo "Connected Succesfully<br>";
// $sql=mysqli_query($con,"create database amazon")or die(mysqli_error($con));
echo "Database Created Succesfully<br>";
$sel=mysqli_select_db($con,"amazon")or die(mysqli_error($con));
echo "Database Selected Succesfully<br>";
// $tab=mysqli_query($con,"create table name2(id int,name varchar(30),address varchar(50),phone int)")or die(mysqli_error($con));
// echo "table created";
if(isset($_POST['sub']))
{
$id=$_POST=["a"];
$name=$_POST=["b"];
$address=$_POST=["c"];
$phone=$_POST=["d"];
$ins=mysqli_query($con,"insert into user(id,name,address,phone) values($id,'$name','$address',$phone)")or die(mysqli_error($con));
echo "Data Inserted Succesfully ";
}
if(isset($_POST['delete']))
{
    $id=$_POST['a'];
    $deleted=mysqli_query($con,"delete from user where id=$id")or die(mysqli_error($con));
    echo "Deleted";
}
if(isset($_POST['select']))
{
    $id=$_POST['a'];
    $selec=mysqli_query($con,"select from user where id=$id")or die(mysqli_error($con));
    echo "Selected";
}
if(isset($_POST['update']))
{
    $id=$_POST['a'];
    $upd=mysqli_query($con,"update from user where id=$id")or die(mysqli_error($con));
    echo "Updated";
}
$up=mysqli_query($con,"update user set name='kiran' where id=101")or die(mysqli_error($con));
echo "Data Updated";
$sql='Select *from user';
$retval=mysqli_query($con,$sql);
if(mysqli_num_rows($retval)>0){
    while($row=mysqli_fetch_assoc($retval)){
        echo "user id:{$row['id']}<br>";
        echo "user name:{$row['name']}<br>";
        echo "user address:{$row['address']}<br>";
        "-----------------------<br>";
    }
}else{
    echo "0 results";
}
mysqli_close($con);
$sql='Select name,address,phone from users where id=101';
?>
<div class="form">
<form method="post">
    enter id=<input type="number" name="a"><br>
    enter name=<input type="text" name="b"><br>
    enter address=<input type="text" name="c"><br>
    enter phone no=<input type="number" name="d"><br>
    <input type="submit" name="sub" value="insert"><input type="submit" name="delete" value="delete"><input type="submit" name="select" value="select"><input type="submit" name="update" value="update">
</form>
</div>